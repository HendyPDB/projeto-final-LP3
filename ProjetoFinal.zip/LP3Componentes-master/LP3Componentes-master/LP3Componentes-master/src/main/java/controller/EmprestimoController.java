package controller;

import model.EmprestimoModel;
import model.LivroModel;
import model.UsuarioModel;
import repository.EmprestimoRepository;

import java.sql.SQLException;
import java.util.List;

public class EmprestimoController {


    EmprestimoRepository emprestimoRepository = new EmprestimoRepository();

    public EmprestimoModel buscarPorId(Long id) {
        return emprestimoRepository.buscarPorId(id);
    }

    public String salvar(EmprestimoModel emprestimo) throws SQLException {
        return emprestimoRepository.salvar(emprestimo);
    }

    public List<EmprestimoModel> buscarTodos() throws SQLException {
        return emprestimoRepository.buscarTodos();
    }

    public String validarEmprestimo(UsuarioModel usuario, LivroModel livro) {
        List<EmprestimoModel> emprestimosAtuais = new EmprestimoRepository().buscarEmprestimosAtivosPorUsuario(usuario.getId());

        if (emprestimosAtuais.size() <= 5) {
            return "O usuário já possui 5 livros emprestados. Não é possível realizar o empréstimo.";
        }

        if (livro.getQuantidadeDisponivel() <= 0) {
            return "O livro selecionado não possui exemplares disponíveis.";
        }

        return "OK";
    }

}
