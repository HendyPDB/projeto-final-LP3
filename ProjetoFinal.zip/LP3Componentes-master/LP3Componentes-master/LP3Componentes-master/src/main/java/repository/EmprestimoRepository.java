package repository;

import model.EmprestimoModel;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.List;

public class EmprestimoRepository {

    private static final EntityManagerFactory factory = Persistence.createEntityManagerFactory("crudHibernatePU");

    private EntityManager getEntityManager() {
        return factory.createEntityManager();
    }

    public String salvar(EmprestimoModel emprestimo) {
        EntityManager entityManager = getEntityManager();
        try {
            entityManager.getTransaction().begin();
            entityManager.persist(emprestimo);
            entityManager.getTransaction().commit();
            return "Empréstimo salvo com sucesso!";
        } catch (Exception e) {
            if (entityManager.getTransaction().isActive()) {
                entityManager.getTransaction().rollback();
            }
            return "Erro ao salvar o empréstimo: " + e.getMessage();
        } finally {
            entityManager.close();
        }
    }

    // Buscar todos os empréstimos
    public List<EmprestimoModel> buscarTodos() {
        EntityManager entityManager = getEntityManager();
        try {
            return entityManager.createQuery("FROM EmprestimoModel", EmprestimoModel.class).getResultList();
        } catch (Exception e) {
            throw new RuntimeException("Erro ao buscar os empréstimos: " + e.getMessage(), e);
        } finally {
            entityManager.close();
        }
    }

    public EmprestimoModel buscarPorId(Long id) {
        EntityManager entityManager = getEntityManager();
        try {
            return entityManager.find(EmprestimoModel.class, id);
        } catch (Exception e) {
            throw new RuntimeException("Erro ao buscar o empréstimo por ID: " + e.getMessage(), e);
        } finally {
            entityManager.close();
        }
    }

    public void atualizar(EmprestimoModel emprestimo) {
        EntityManager entityManager = getEntityManager();
        try {
            entityManager.getTransaction().begin();
            EmprestimoModel emprestimoExistente = entityManager.find(EmprestimoModel.class, emprestimo.getId());
            if (emprestimoExistente != null) {
                // Atualiza o campo necessário (como a data de devolução)
                emprestimoExistente.setDataDevolucao(emprestimo.getDataDevolucao());
                entityManager.merge(emprestimoExistente);
                entityManager.getTransaction().commit();
            } else {
                throw new RuntimeException("Empréstimo não encontrado para atualização.");
            }
        } catch (Exception e) {
            if (entityManager.getTransaction().isActive()) {
                entityManager.getTransaction().rollback();
            }
            throw new RuntimeException("Erro ao atualizar o empréstimo: " + e.getMessage(), e);
        } finally {
            entityManager.close();
        }
    }

    public List<EmprestimoModel> buscarEmprestimosAtivosPorUsuario(Long idUsuario) {
        EntityManager entityManager = getEntityManager();
        try {
            return entityManager.createQuery(
                            "SELECT e FROM EmprestimoModel e WHERE e.usuario.id = :idUsuario AND e.dataDevolucao IS NULL",
                            EmprestimoModel.class)
                    .setParameter("idUsuario", idUsuario)
                    .getResultList();
        } catch (Exception e) {
            throw new RuntimeException("Erro ao buscar empréstimos ativos para o usuário: " + e.getMessage(), e);
        } finally {
            entityManager.close();
        }
    }
}
