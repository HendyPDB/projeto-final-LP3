package view;

import controller.UsuarioController;
import model.UsuarioModel;

import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;

public class EditarUsuario extends JFrame {
    private JPanel panelPrincipal;
    private JTextField textFieldNome;
    private JTextField textFieldSexo;
    private JTextField textFieldNumeroCelular;
    private JTextField textFieldEmail;
    private JButton salvarButton;
    private UsuarioModel usuario;

    private UsuarioController usuarioController = new UsuarioController();

    public EditarUsuario(JFrame parentFrame, UsuarioModel usuario) {
        this.usuario = usuario;

        this.setTitle("Editar Usuário");
        this.setSize(400, 300);
        this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        this.setLayout(new BorderLayout());

        panelPrincipal = new JPanel(new GridLayout(5, 2, 10, 10));
        panelPrincipal.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        panelPrincipal.add(new JLabel("Nome:"));
        textFieldNome = new JTextField(usuario.getNome());
        panelPrincipal.add(textFieldNome);

        panelPrincipal.add(new JLabel("Sexo:"));
        textFieldSexo = new JTextField(usuario.getSexo());
        panelPrincipal.add(textFieldSexo);

        panelPrincipal.add(new JLabel("Número de Celular:"));
        textFieldNumeroCelular = new JTextField(usuario.getNumeroCelular());
        panelPrincipal.add(textFieldNumeroCelular);

        panelPrincipal.add(new JLabel("Email:"));
        textFieldEmail = new JTextField(usuario.getEmail());
        panelPrincipal.add(textFieldEmail);

        salvarButton = new JButton("Salvar");
        panelPrincipal.add(new JLabel());
        panelPrincipal.add(salvarButton);

        this.add(panelPrincipal, BorderLayout.CENTER);
        this.setLocationRelativeTo(parentFrame);
        this.setVisible(true);

        salvarButton.addActionListener(e -> salvarEdicao());
    }

    private void salvarEdicao() {
        try {
            usuario.setNome(textFieldNome.getText());
            usuario.setSexo(textFieldSexo.getText());
            usuario.setNumeroCelular(textFieldNumeroCelular.getText());
            usuario.setEmail(textFieldEmail.getText());

            String resultado = usuarioController.editar(usuario);
            JOptionPane.showMessageDialog(this, resultado);

            if (resultado.contains("sucesso")) {
                this.dispose();
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Erro ao salvar o usuário: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
}
