package view;

import controller.LivroController;
import model.LivroModel;
import repository.LivroRepository;

import javax.swing.*;
import javax.swing.table.AbstractTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Collections;
import java.util.List;

public class BuscarLivro extends JFrame {
    private LivroController livroController = new LivroController();
    private JPanel panelPrincipal;
    private JTextField textFieldBusca;
    private JButton buttonBuscar;
    private JButton buttonDisponiveis;
    private JTable tableBuscaLivro;
    private JScrollPane scrollPaneLivro;
    private JButton removerButton;
    private JButton editarButton;

    public BuscarLivro() {
        this.setTitle("Sistema de Gestão de Biblioteca - Buscar Livro");
        this.setSize(640, 480);
        this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        createUIComponents();
        this.setContentPane(panelPrincipal);
        this.setVisible(true);

        LivroModeloDeTabela livroModeloDeTabela = new LivroModeloDeTabela();
        tableBuscaLivro.setModel(livroModeloDeTabela);
        tableBuscaLivro.setAutoCreateRowSorter(true);

        removerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int linhaSelecionada = tableBuscaLivro.getSelectedRow();
                if (linhaSelecionada != -1) {
                    try {
                        Long idLivro = Long.parseLong(tableBuscaLivro.getValueAt(linhaSelecionada, 0).toString());
                        String resultado = livroController.remover(idLivro);
                        JOptionPane.showMessageDialog(null, resultado);
                        atualizarTabela();
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(null, "Erro ao remover o livro: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Selecione um registro para remover.", "Aviso", JOptionPane.WARNING_MESSAGE);
                }
            }
        });

        editarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int linhaSelecionada = tableBuscaLivro.getSelectedRow();
                if (linhaSelecionada != -1) {
                    try {
                        Long idLivro = Long.parseLong(tableBuscaLivro.getValueAt(linhaSelecionada, 0).toString());
                        LivroModel livro = livroController.buscarPorId(idLivro);
                        if (livro != null) {
                            new EditarLivro(BuscarLivro.this, livro);
                        } else {
                            JOptionPane.showMessageDialog(null, "Livro não encontrado.", "Erro", JOptionPane.ERROR_MESSAGE);
                        }
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(null, "Erro ao editar o livro: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Selecione um registro para editar.", "Aviso", JOptionPane.WARNING_MESSAGE);
                }
            }
        });

        buttonBuscar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String textoBusca = textFieldBusca.getText().trim();
                if (!textoBusca.isEmpty()) {
                    try {
                        Long idBusca = Long.parseLong(textoBusca);
                        atualizarTabelaPorId(idBusca);
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(null, "ID inválido. Insira um número válido.", "Erro", JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    atualizarTabela();
                }
            }
        });

        buttonDisponiveis.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                atualizarTabelaDisponiveis();
            }
        });
    }

    private void atualizarTabela() {
        LivroModeloDeTabela livroModeloDeTabela = new LivroModeloDeTabela();
        tableBuscaLivro.setModel(livroModeloDeTabela);
    }

    private void atualizarTabelaPorId(Long id) {
        LivroModeloDeTabela livroModeloDeTabela = new LivroModeloDeTabela(id);
        tableBuscaLivro.setModel(livroModeloDeTabela);
    }

    private void atualizarTabelaDisponiveis() {
        LivroModeloDeTabela livroModeloDeTabela = new LivroModeloDeTabela(true);  // Construtor para listar livros disponíveis
        tableBuscaLivro.setModel(livroModeloDeTabela);
    }

    private void createUIComponents() {
        panelPrincipal = new JPanel();
        panelPrincipal.setLayout(new BorderLayout());

        JPanel panelBusca = new JPanel(new FlowLayout());
        textFieldBusca = new JTextField(20);
        buttonBuscar = new JButton("Buscar");
        buttonDisponiveis = new JButton("Listar Livros Disponíveis");
        panelBusca.add(new JLabel("Buscar por ID:"));
        panelBusca.add(textFieldBusca);
        panelBusca.add(buttonBuscar);
        panelBusca.add(buttonDisponiveis);

        tableBuscaLivro = new JTable();
        scrollPaneLivro = new JScrollPane(tableBuscaLivro);
        removerButton = new JButton("Remover");
        editarButton = new JButton("Editar");

        JPanel panelBotoes = new JPanel(new FlowLayout());
        panelBotoes.add(removerButton);
        panelBotoes.add(editarButton);

        // add os componentes ao painel principal
        panelPrincipal.add(panelBusca, BorderLayout.NORTH);
        panelPrincipal.add(scrollPaneLivro, BorderLayout.CENTER);
        panelPrincipal.add(panelBotoes, BorderLayout.SOUTH);
    }

    private static class LivroModeloDeTabela extends AbstractTableModel {
        private final String[] colunasDaTabela = {"Id", "Título", "Tema", "Autor", "ISBN", "Quantidade Disponível", "Data da Publicação"};
        private List<LivroModel> listaDeLivros;

        public LivroModeloDeTabela() {
            listaDeLivros = new LivroRepository().buscarTodos();
        }

        public LivroModeloDeTabela(Long id) {
            LivroModel livro = new LivroRepository().buscarPorId(id);
            listaDeLivros = livro != null ? List.of(livro) : Collections.emptyList();
        }

        public LivroModeloDeTabela(boolean disponiveis) {
            listaDeLivros = new LivroRepository().buscarLivrosDisponiveis();
        }

        @Override
        public int getRowCount() {
            return listaDeLivros.size();
        }

        @Override
        public int getColumnCount() {
            return colunasDaTabela.length;
        }

        @Override
        public Object getValueAt(int rowIndex, int columnIndex) {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            LivroModel livro = listaDeLivros.get(rowIndex);
            return switch (columnIndex) {
                case 0 -> livro.getId();
                case 1 -> livro.getTitulo();
                case 2 -> livro.getTema();
                case 3 -> livro.getAutor();
                case 4 -> livro.getIsbn();
                case 5 -> livro.getQuantidadeDisponivel();
                case 6 -> livro.getDataPublicacao() != null ? livro.getDataPublicacao().format(formatter) : "-";
                default -> "-";
            };
        }

        @Override
        public String getColumnName(int columnIndex) {
            return colunasDaTabela[columnIndex];
        }
    }
}