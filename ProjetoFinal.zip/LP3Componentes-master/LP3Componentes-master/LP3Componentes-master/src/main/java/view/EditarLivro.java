package view;

import controller.LivroController;
import model.LivroModel;

import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public class EditarLivro extends JFrame {
    private JPanel panelPrincipal;
    private JTextField textFieldTitulo;
    private JTextField textFieldTema;
    private JTextField textFieldAutor;
    private JTextField textFieldIsbn;
    private JTextField textFieldQuantidade;
    private JFormattedTextField textFieldDataPublicacao;
    private JButton salvarButton;

    private LivroController livroController = new LivroController();
    private LivroModel livro;

    public EditarLivro(JFrame parentFrame, LivroModel livro) {
        this.livro = livro;

        this.setTitle("Editar Livro");
        this.setSize(400, 300);
        this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        this.setLayout(new BorderLayout());

        panelPrincipal = new JPanel(new GridLayout(7, 2, 10, 10));
        panelPrincipal.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        panelPrincipal.add(new JLabel("Título:"));
        textFieldTitulo = new JTextField(livro.getTitulo());
        panelPrincipal.add(textFieldTitulo);

        panelPrincipal.add(new JLabel("Tema:"));
        textFieldTema = new JTextField(livro.getTema());
        panelPrincipal.add(textFieldTema);

        panelPrincipal.add(new JLabel("Autor:"));
        textFieldAutor = new JTextField(livro.getAutor());
        panelPrincipal.add(textFieldAutor);

        panelPrincipal.add(new JLabel("ISBN:"));
        textFieldIsbn = new JTextField(livro.getIsbn());
        panelPrincipal.add(textFieldIsbn);

        panelPrincipal.add(new JLabel("Quantidade Disponível:"));
        textFieldQuantidade = new JTextField(String.valueOf(livro.getQuantidadeDisponivel()));
        panelPrincipal.add(textFieldQuantidade);

        panelPrincipal.add(new JLabel("Data de Publicação (dd/MM/yyyy):"));
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        textFieldDataPublicacao = new JFormattedTextField(formatter);
        textFieldDataPublicacao.setText(livro.getDataPublicacao() != null ? livro.getDataPublicacao().format(formatter) : "");
        panelPrincipal.add(textFieldDataPublicacao);

        salvarButton = new JButton("Salvar");
        panelPrincipal.add(new JLabel());
        panelPrincipal.add(salvarButton);

        this.add(panelPrincipal, BorderLayout.CENTER);
        this.setLocationRelativeTo(parentFrame);
        this.setVisible(true);

        salvarButton.addActionListener(e -> salvarEdicao());
    }

    private void salvarEdicao() {
        try {
            livro.setTitulo(textFieldTitulo.getText());
            livro.setTema(textFieldTema.getText());
            livro.setAutor(textFieldAutor.getText());
            livro.setIsbn(textFieldIsbn.getText());

            try {
                int quantidade = Integer.parseInt(textFieldQuantidade.getText());
                livro.setQuantidadeDisponivel(quantidade);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Quantidade deve ser um número válido.", "Erro", JOptionPane.ERROR_MESSAGE);
                return;
            }

            try {
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                LocalDate dataPublicacao = LocalDate.parse(textFieldDataPublicacao.getText(), formatter);
                livro.setDataPublicacao(dataPublicacao);
            } catch (DateTimeParseException ex) {
                JOptionPane.showMessageDialog(this, "Data inválida! Use o formato dd/MM/yyyy.", "Erro", JOptionPane.ERROR_MESSAGE);
                return;
            }

            String resultado = livroController.editar(livro);
            JOptionPane.showMessageDialog(this, resultado);

            if (resultado.contains("sucesso")) {
                this.dispose();
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Erro ao salvar o livro: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
}
