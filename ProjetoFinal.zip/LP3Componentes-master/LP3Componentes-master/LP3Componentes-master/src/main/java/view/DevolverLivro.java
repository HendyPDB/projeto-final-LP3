package view;

import controller.EmprestimoController;
import controller.LivroController;
import model.EmprestimoModel;
import model.LivroModel;
import repository.EmprestimoRepository;

import javax.swing.*;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.text.MaskFormatter;
import java.awt.*;
import java.sql.SQLException;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoUnit;
import java.util.List;

public class DevolverLivro extends JFrame {
    private JTable tableEmprestimos;
    private JButton devolverButton;
    private MeuModeloDeTabela modeloTabela;
    private static final double MULTA_POR_DIA = 2.50;
    public DevolverLivro() {
        this.setTitle("Devolver Livro");
        this.setSize(640, 480);
        this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        this.setLayout(new BorderLayout());

        tableEmprestimos = new JTable();
        JScrollPane scrollPane = new JScrollPane(tableEmprestimos);
        this.add(scrollPane, BorderLayout.CENTER);

        devolverButton = new JButton("Devolver Livro");
        this.add(devolverButton, BorderLayout.SOUTH);

        devolverButton.addActionListener(e -> {
            int linhaSelecionada = tableEmprestimos.getSelectedRow();
            if (linhaSelecionada != -1) {
                EmprestimoModel emprestimo = modeloTabela.getEmprestimoAt(linhaSelecionada);
                if (emprestimo.getDataDevolucao() == null) {
                    exibirDialogoDevolucao(emprestimo, linhaSelecionada);
                } else {
                    JOptionPane.showMessageDialog(this, "O livro já foi devolvido.", "Aviso", JOptionPane.WARNING_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(this, "Selecione um empréstimo para devolver.", "Aviso", JOptionPane.WARNING_MESSAGE);
            }
        });

        atualizarTabela();
        configurarRenderizacaoDeLinhas();  // destaca emprestimos atrasados
        this.setVisible(true);
    }

    private void exibirDialogoDevolucao(EmprestimoModel emprestimo, int linhaSelecionada) {
        JDialog dialog = new JDialog(this, "Informe a Data de Devolução", true);
        dialog.setSize(300, 150);
        dialog.setLayout(new FlowLayout());

        JLabel labelDataDevolucao = new JLabel("Data de Devolução (dd/MM/yyyy):");
        JFormattedTextField campoDataDevolucao = criarCampoData();

        JButton confirmarButton = new JButton("Confirmar");
        confirmarButton.addActionListener(e -> {
            String dataDevolucaoStr = campoDataDevolucao.getText().trim();
            if (!dataDevolucaoStr.contains("_")) {
                try {
                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                    LocalDate dataDevolucao = LocalDate.parse(dataDevolucaoStr, formatter);
                    LocalDate dataPrevista = emprestimo.getDataDevolucaoPrevista();

                    // faz o calculo da multa se tiver
                    long diasDeAtraso = ChronoUnit.DAYS.between(dataPrevista, dataDevolucao);
                    double multa = diasDeAtraso > 0 ? diasDeAtraso * MULTA_POR_DIA : 0.0;

                    if (multa > 0) {
                        int confirmacao = JOptionPane.showConfirmDialog(this,
                                String.format("O livro está com %d dias de atraso.\nMulta: R$ %.2f\nDeseja confirmar a devolução?", diasDeAtraso, multa),
                                "Confirmação de Multa", JOptionPane.YES_NO_OPTION);

                        if (confirmacao == JOptionPane.NO_OPTION) {
                            return;
                        }
                    }

                    emprestimo.setDataDevolucao(dataDevolucao);
                    atualizarDataDevolucao(emprestimo, linhaSelecionada);
                    dialog.dispose();
                } catch (DateTimeParseException ex) {
                    JOptionPane.showMessageDialog(this, "Data inválida! Use o formato dd/MM/yyyy.", "Erro", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(this, "Preencha completamente a data de devolução.", "Erro", JOptionPane.ERROR_MESSAGE);
            }
        });

        dialog.add(labelDataDevolucao);
        dialog.add(campoDataDevolucao);
        dialog.add(confirmarButton);
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

    private JFormattedTextField criarCampoData() {
        try {
            MaskFormatter dataFormatter = new MaskFormatter("##/##/####");
            dataFormatter.setPlaceholderCharacter('_');
            return new JFormattedTextField(dataFormatter);
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
    }

    private void atualizarTabela() {
        List<EmprestimoModel> listaEmprestimos = new EmprestimoRepository().buscarTodos();
        modeloTabela = new MeuModeloDeTabela(listaEmprestimos);
        tableEmprestimos.setModel(modeloTabela);
    }

    private void atualizarDataDevolucao(EmprestimoModel emprestimo, int linhaSelecionada) {
        try {

            new EmprestimoRepository().atualizar(emprestimo);

            LivroModel livro = emprestimo.getLivro();
            livro.setQuantidadeDisponivel(livro.getQuantidadeDisponivel() + 1);
            new LivroController().editar(livro);

            EmprestimoModel emprestimoAtualizado = new EmprestimoRepository().buscarPorId(emprestimo.getId());

            if (emprestimoAtualizado != null) {
                modeloTabela.atualizarEmprestimo(emprestimoAtualizado, linhaSelecionada);
                JOptionPane.showMessageDialog(this, "Livro devolvido com sucesso!");
            } else {
                JOptionPane.showMessageDialog(this, "Erro ao buscar o empréstimo atualizado.", "Erro", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Erro ao devolver o livro: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void configurarRenderizacaoDeLinhas() {
        tableEmprestimos.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                                                           boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                EmprestimoModel emprestimo = modeloTabela.getEmprestimoAt(row);
                LocalDate hoje = LocalDate.now();
                LocalDate dataPrevista = emprestimo.getDataDevolucaoPrevista();

                if (emprestimo.getDataDevolucao() == null && dataPrevista.isBefore(hoje)) {
                    c.setBackground(Color.RED);  // destaca empréstimos atrasados
                    c.setForeground(Color.WHITE);
                } else {
                    c.setBackground(isSelected ? table.getSelectionBackground() : table.getBackground());
                    c.setForeground(isSelected ? table.getSelectionForeground() : table.getForeground());
                }

                return c;
            }
        });
    }

    private static class MeuModeloDeTabela extends AbstractTableModel {
        private final String[] colunas = {"ID", "Usuário", "Livro", "Data Empréstimo", "Data Devolução Prevista", "Data Devolução"};
        private final List<EmprestimoModel> emprestimos;

        public MeuModeloDeTabela(List<EmprestimoModel> emprestimos) {
            this.emprestimos = emprestimos;
        }

        @Override
        public int getRowCount() {
            return emprestimos.size();
        }

        @Override
        public int getColumnCount() {
            return colunas.length;
        }

        @Override
        public Object getValueAt(int rowIndex, int columnIndex) {
            EmprestimoModel emprestimo = emprestimos.get(rowIndex);
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            return switch (columnIndex) {
                case 0 -> emprestimo.getId();
                case 1 -> emprestimo.getUsuario();
                case 2 -> emprestimo.getLivro().getTitulo();
                case 3 -> emprestimo.getDataEmprestimo().format(formatter);
                case 4 -> emprestimo.getDataDevolucaoPrevista().format(formatter);
                case 5 -> (emprestimo.getDataDevolucao() != null) ? emprestimo.getDataDevolucao().format(formatter) : "Não devolvido";
                default -> null;
            };
        }

        @Override
        public String getColumnName(int columnIndex) {
            return colunas[columnIndex];
        }

        public EmprestimoModel getEmprestimoAt(int rowIndex) {
            return emprestimos.get(rowIndex);
        }

        public void atualizarEmprestimo(EmprestimoModel emprestimoAtualizado, int rowIndex) {
            emprestimos.set(rowIndex, emprestimoAtualizado);
            fireTableRowsUpdated(rowIndex, rowIndex);  // att a linha correspondente
        }
    }
}
