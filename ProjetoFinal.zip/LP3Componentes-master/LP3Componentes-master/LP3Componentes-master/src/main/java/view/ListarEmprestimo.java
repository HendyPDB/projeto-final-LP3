package view;

import model.EmprestimoModel;
import repository.EmprestimoRepository;

import javax.swing.*;
import javax.swing.table.AbstractTableModel;
import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class ListarEmprestimo extends JFrame {
    private JTable tableEmprestimos;

    public ListarEmprestimo() {
        this.setTitle("Listar Empréstimos");
        this.setSize(640, 480);
        this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        this.setLayout(new BorderLayout());

        tableEmprestimos = new JTable();
        JScrollPane scrollPane = new JScrollPane(tableEmprestimos);
        this.add(scrollPane, BorderLayout.CENTER);

        atualizarTabela();
        this.setVisible(true);
    }

    private void atualizarTabela() {
        List<EmprestimoModel> listaEmprestimos = new EmprestimoRepository().buscarTodos();
        tableEmprestimos.setModel(new MeuModeloDeTabela(listaEmprestimos));
    }

    private static class MeuModeloDeTabela extends AbstractTableModel {
        private final String[] colunas = {"ID", "Usuário", "Livro", "Data Empréstimo", "Data Devolução Prevista", "Data Devolução"};
        private final List<EmprestimoModel> emprestimos;

        public MeuModeloDeTabela(List<EmprestimoModel> emprestimos) {
            this.emprestimos = emprestimos;
        }

        @Override
        public int getRowCount() {
            return emprestimos.size();
        }

        @Override
        public int getColumnCount() {
            return colunas.length;
        }

        @Override
        public Object getValueAt(int rowIndex, int columnIndex) {
            EmprestimoModel emprestimo = emprestimos.get(rowIndex);
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

            switch (columnIndex) {
                case 0: return emprestimo.getId();
                case 1: return emprestimo.getUsuario();
                case 2: return emprestimo.getLivro().getTitulo();
                case 3: return emprestimo.getDataEmprestimo().format(formatter);
                case 4: return emprestimo.getDataDevolucaoPrevista().format(formatter);
                case 5:
                    if (emprestimo.getDataDevolucao() == null) {
                        return (emprestimo.getDataDevolucaoPrevista().isBefore(LocalDate.now())) ?
                                "Atrasado" : "Não devolvido";
                    } else {
                        return emprestimo.getDataDevolucao().format(formatter);
                    }
                default: return null;
            }
        }


        @Override
        public String getColumnName(int columnIndex) {
            return colunas[columnIndex];
        }
    }
}
