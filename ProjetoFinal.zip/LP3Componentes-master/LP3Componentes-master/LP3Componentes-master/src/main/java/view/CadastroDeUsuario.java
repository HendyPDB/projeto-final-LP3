package view;

import com.google.protobuf.TextFormat;
import controller.UsuarioController;
import model.UsuarioModel;

import javax.swing.*;
import javax.swing.text.MaskFormatter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.text.ParseException;

public class CadastroDeUsuario extends JFrame {
    private JPanel jpanelPrincipal;
    private JPanel Principal;
    private JTextField textFieldNome;
    private JTextField textFieldSexo;
    private JFormattedTextField textFieldNumeroCelular;
    private JTextField textFieldEmail;
    private JLabel jLabelTitulo;
    private JLabel jLabelNome;
    private JLabel jLabelSexo;
    private JLabel jLabelEmail;
    private JLabel jLabelNumeroCelular;
    private JButton buttonEnviar;
    private UsuarioController usuarioController = new UsuarioController();

    public CadastroDeUsuario() {
        this.setTitle("Cadastro de Usuário - Sistema de Gestão de Biblioteca");
        this.setSize(300, 200);
        this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        this.add(jpanelPrincipal);  // add o painel principal ao frame

        buttonEnviar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                UsuarioModel usuario = new UsuarioModel();
                usuario.setNome(textFieldNome.getText());
                usuario.setSexo(textFieldSexo.getText());
                usuario.setNumeroCelular(textFieldNumeroCelular.getText());
                usuario.setEmail(textFieldEmail.getText());

                try {
                    String resultado = usuarioController.salvar(usuario);
                    JOptionPane.showMessageDialog(null, resultado);

                    if (resultado.contains("sucesso")) {
                        dispose(); 
                        new Principal();  //redirecionamento para a tela principal
                    }
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null, "Erro ao salvar o usuário: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        this.setVisible(true);
    }

    private void createUIComponents() {
        try {
            MaskFormatter maskFormatter = new MaskFormatter("(##) #####-####");
            maskFormatter.setPlaceholderCharacter('_');

            textFieldNumeroCelular = new JFormattedTextField(maskFormatter);
        } catch (ParseException e) {
            JOptionPane.showMessageDialog(null, "Erro ao aplicar a máscara no campo de celular.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }


}