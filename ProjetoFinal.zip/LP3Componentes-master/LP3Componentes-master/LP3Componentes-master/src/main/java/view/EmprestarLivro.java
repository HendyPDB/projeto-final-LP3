package view;

import controller.EmprestimoController;
import controller.LivroController;
import controller.UsuarioController;
import repository.EmprestimoRepository;
import model.EmprestimoModel;
import model.LivroModel;
import model.UsuarioModel;

import javax.swing.*;
import javax.swing.text.MaskFormatter;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;

public class EmprestarLivro extends JFrame {
    private JPanel jpanelPrincipal;
    private JPanel Principal;
    private JComboBox<LivroModel> comboBoxLivros;
    private JComboBox<UsuarioModel> comboBoxUsuarios;
    private JFormattedTextField textFieldDataEmprestimo;
    private JFormattedTextField textFieldDataDevolucaoPrevista;
    private JFormattedTextField textFieldDataDevolucao;
    private JTextField textFieldUsuario;
    private JButton emprestarButton;
    private JLabel labelTitulo;
    private JLabel labelTema;
    private JLabel labelAutor;
    private JLabel labelISBN;
    private JLabel labelDataPublicacao;
    private JLabel labelQuantidadeDisponivel;
    private JLabel jLabelcadastrarEmprestimo;
    private JLabel jLabelusuario;
    private JLabel jLabeldataDoEmprestimo;
    private JLabel jLabeldataDeDevolucaoPrevista;
    private JLabel jLabeldataDeDevolucao;

    private EmprestimoController emprestimoController = new EmprestimoController();
    private LivroController livroController = new LivroController();
    private UsuarioController usuarioController = new UsuarioController();
    private EmprestimoRepository emprestimoRepository = new EmprestimoRepository();


    public EmprestarLivro() {
        createUIComponents();

        this.setTitle("Empréstimo de Livro - Sistema de Gestão de Biblioteca");
        this.setContentPane(jpanelPrincipal);
        this.setSize(300, 400);
        this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        this.setVisible(true);

        try {
            List<LivroModel> livrosDisponiveis = livroController.buscarTodos();
            for (LivroModel livro : livrosDisponiveis) {
                comboBoxLivros.addItem(livro);
            }

            List<UsuarioModel> usuariosCadastrados = usuarioController.buscarTodos();
            for (UsuarioModel usuario : usuariosCadastrados) {
                comboBoxUsuarios.addItem(usuario);
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao buscar dados: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }

        comboBoxLivros.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                LivroModel livroSelecionado = (LivroModel) comboBoxLivros.getSelectedItem();
                if (livroSelecionado != null) {
                    labelTitulo.setText(livroSelecionado.getTitulo());
                    labelTema.setText(livroSelecionado.getTema());
                    labelAutor.setText(livroSelecionado.getAutor());
                    labelISBN.setText(livroSelecionado.getIsbn());
                    labelDataPublicacao.setText(livroSelecionado.getDataPublicacao().toString());
                    labelQuantidadeDisponivel.setText(String.valueOf(livroSelecionado.getQuantidadeDisponivel()));
                }
            }
        });

        emprestarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    LivroModel livroSelecionado = (LivroModel) comboBoxLivros.getSelectedItem();
                    UsuarioModel usuarioSelecionado = (UsuarioModel) comboBoxUsuarios.getSelectedItem();

                    if (livroSelecionado == null || usuarioSelecionado == null) {
                        JOptionPane.showMessageDialog(null, "Selecione um livro e um usuário válidos.", "Erro", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    // limite de 5 livros
                    List<EmprestimoModel> emprestimosAtivos = emprestimoRepository.buscarEmprestimosAtivosPorUsuario(usuarioSelecionado.getId());
                    if (emprestimosAtivos.size() >= 5) {
                        JOptionPane.showMessageDialog(null, "O usuário já possui 5 livros emprestados.", "Erro", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    if (livroSelecionado.getQuantidadeDisponivel() <= 0) {
                        JOptionPane.showMessageDialog(null, "Livro indisponível para empréstimo.", "Erro", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                    LocalDate dataEmprestimo;
                    LocalDate dataDevolucaoPrevista;

                    try {
                        dataEmprestimo = LocalDate.parse(textFieldDataEmprestimo.getText().trim(), formatter);
                        dataDevolucaoPrevista = LocalDate.parse(textFieldDataDevolucaoPrevista.getText().trim(), formatter);
                    } catch (DateTimeParseException ex) {
                        JOptionPane.showMessageDialog(null, "Datas inválidas! Use o formato dd/MM/yyyy.", "Erro", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    // prazo máximo de 14 dias
                    if (dataDevolucaoPrevista.isAfter(dataEmprestimo.plusDays(14))) {
                        JOptionPane.showMessageDialog(null, "O prazo máximo de empréstimo é de 14 dias.", "Erro", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    EmprestimoModel emprestimo = new EmprestimoModel(usuarioSelecionado, livroSelecionado, dataEmprestimo, dataDevolucaoPrevista, null);
                    String resultado = emprestimoController.salvar(emprestimo);

                    if (resultado.contains("sucesso")) {
                        livroSelecionado.setQuantidadeDisponivel(livroSelecionado.getQuantidadeDisponivel() - 1);
                        livroController.editar(livroSelecionado);
                    }

                    JOptionPane.showMessageDialog(null, resultado);
                    if (resultado.contains("sucesso")) {
                        dispose();
                    }

                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null, "Erro ao registrar o empréstimo: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
    }

    private void createUIComponents() {
        try {
            jpanelPrincipal = new JPanel();
            jpanelPrincipal.setLayout(new BoxLayout(jpanelPrincipal, BoxLayout.Y_AXIS));

            comboBoxLivros = new JComboBox<>();
            comboBoxUsuarios = new JComboBox<>();

            MaskFormatter dataFormatter = new MaskFormatter("##/##/####");
            dataFormatter.setPlaceholderCharacter('_');

            textFieldDataEmprestimo = new JFormattedTextField(dataFormatter);
            textFieldDataDevolucaoPrevista = new JFormattedTextField(dataFormatter);

            labelTitulo = new JLabel("-");
            labelTema = new JLabel("-");
            labelAutor = new JLabel("-");
            labelISBN = new JLabel("-");
            labelDataPublicacao = new JLabel("-");
            labelQuantidadeDisponivel = new JLabel("-");
            emprestarButton = new JButton("Emprestar");

            jpanelPrincipal.add(new JLabel("Livro:"));
            jpanelPrincipal.add(comboBoxLivros);

            jpanelPrincipal.add(new JLabel("Usuário:"));
            jpanelPrincipal.add(comboBoxUsuarios);

            jpanelPrincipal.add(new JLabel("Data do Empréstimo:"));
            jpanelPrincipal.add(textFieldDataEmprestimo);

            jpanelPrincipal.add(new JLabel("Data de Devolução Prevista:"));
            jpanelPrincipal.add(textFieldDataDevolucaoPrevista);

            jpanelPrincipal.add(new JLabel("Título:"));
            jpanelPrincipal.add(labelTitulo);

            jpanelPrincipal.add(new JLabel("Tema:"));
            jpanelPrincipal.add(labelTema);

            jpanelPrincipal.add(new JLabel("Autor:"));
            jpanelPrincipal.add(labelAutor);

            jpanelPrincipal.add(new JLabel("ISBN:"));
            jpanelPrincipal.add(labelISBN);

            jpanelPrincipal.add(new JLabel("Data de Publicação:"));
            jpanelPrincipal.add(labelDataPublicacao);

            jpanelPrincipal.add(new JLabel("Quantidade Disponível:"));
            jpanelPrincipal.add(labelQuantidadeDisponivel);

            jpanelPrincipal.add(emprestarButton);

        } catch (ParseException e) {
            e.printStackTrace();
        }
    }
}